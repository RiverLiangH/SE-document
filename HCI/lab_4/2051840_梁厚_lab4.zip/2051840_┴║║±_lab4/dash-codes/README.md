# Data Visualization ---- College Salary

## Introduction

This is a simple data-visualized app based on dash and ploty and developed by one college student. It briefly visualize the data in lab4-datasets/college-salaries and show some pattern behind the data.



## How to run

**Prereuirement**

- Python 3.8
- ploty 5.14.1
- dash 2.9.3
- pandas 2.0.1



Please install the packages and make sure they are correct version before you start.

Then run college-salaries-dash-app.py in your local IDE.

