import numpy as np
from dash import Dash, html, dcc, callback, Output, Input
import plotly.express as px
import plotly.graph_objects as go
import pandas as pd

colors = {
    'background': '#111111',
    'text': '#7FDBFF'
}

df_type = pd.read_csv('lab4-datasets/college-salaries/salaries-by-college-type.csv')
df_region = pd.read_csv('lab4-datasets/college-salaries/salaries-by-region.csv')
df = pd.read_csv('https://raw.githubusercontent.com/plotly/datasets/master/gapminder_unfiltered.csv')

#
# df_type['Mid-Career 90th Percentile Salary'] = pd.to_numeric(df_type['Mid-Career 90th Percentile Salary'])
# df_type['Mid-Career 25th Percentile Salary'] = pd.to_numeric(df_type['Mid-Career 25th Percentile Salary'])

# fig = px.scatter(df_type,
#                  x="Starting Median Salary",
#                  y="Mid-Career 25th Percentile Salary",
#                  color="School Name")


app = Dash(__name__)

app.layout = html.Div(style={'backgroundColor': colors['background']}, children=[
    html.H1(
        children='College Salary Analysis',
        style={
            'textAlign': 'center',
            'color': colors['text']
        }
    ),
    html.Div(style={'backgroundColor': colors['background']}, children=[
        # Bar Chart
        html.Div(children=[
            html.H4('Starting Median Salary of students from different schools in U.S'),
            dcc.Graph(id="graph"),
            html.P("Number of bars:"),
            dcc.Slider(id="slider", min=50, max=250, value=4, step=50),
        ]),
        # scatter plot
        html.Div(children=[
            html.H4('Salary of students with different majors'),
            dcc.Graph(id="scatter-plot"),
            html.P("Filter by petal width:"),
            dcc.RangeSlider(
                id='range-slider',
                min=10000, max=50000, step=100,
                marks={10000: '0', 50000: '10'}
            )
        ]),
        # scatter plot
        html.Div(children=[
            html.H4('Salary of students with different majors'),
            dcc.Graph(id="scatter-plot-1"),
            html.P("Filter by petal width:"),
            dcc.RangeSlider(
                id='range-slider-1',
                min=10000, max=50000, step=100,
                marks={10000: '0', 50000: '10'}
            )
        ])
    ])
])

# @callback(
#     Output('graph-content', 'figure'),
#     Input('dropdown-selection', 'value')
# )
# def update_graph(value):
#     dff = df[df.country==value]
#     return px.line(dff, x='year', y='pop')


# Pie Chart
@app.callback(
    Output("graph", "figure"),
    Input("slider", "value"))
def update_bar_chart(size):
    data = df_region["Starting Median Salary"]
    # data = np.random.normal(3, 2, size=size) # replace with your own data source
    fig = go.Figure(
        data=[go.Bar(y=data)],
        layout_title_text="Native Plotly rendering in Dash"
    )
    return fig

@app.callback(
    Output("scatter-plot", "figure"),
    Input("range-slider", "value"))
def update_bar_chart(slider_range):
    # low, high = slider_range
    # mask = (df['petal_width'] > low) & (df['petal_width'] < high)
    fig = px.scatter(
        df_type,
        x="Starting Median Salary",
        y="Mid-Career 25th Percentile Salary",
        color="School Type")
    return fig

@app.callback(
    Output("scatter-plot-1", "figure"),
    Input("range-slider-1", "value"))
def update_bar_chart(slider_range):
    # low, high = slider_range
    # mask = (df['petal_width'] > low) & (df['petal_width'] < high)
    fig = px.scatter(
        df_type,
        x="Starting Median Salary",
        y="Mid-Career 90th Percentile Salary",
        color="School Type")
    return fig



if __name__ == '__main__':
    app.run_server(debug=True)
